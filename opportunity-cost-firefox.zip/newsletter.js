document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('newsletter-form');
  const successMessage = document.getElementById('success-message');
  
  // Detect which browser API to use (Chrome or Firefox)
  const browserAPI = typeof chrome !== 'undefined' ? chrome : browser;
  
  form.addEventListener('submit', async function(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    
    try {
      // Show success message (we do this first for better user experience)
      form.style.display = 'none';
      successMessage.style.display = 'block';
      
      // Store subscription status in extension storage
      browserAPI.storage.local.set({
        'newsletter_subscribed': true,
        'newsletter_email': email
      });

      // Send this info to background script for Ghost CMS integration
      console.log('Sending newsletter signup to background script:', email);
      
      browserAPI.runtime.sendMessage({
        action: 'newsletterSignup',
        email: email
      }, function(response) {
        console.log('Newsletter signup response:', response);
        
        // If there was an error with the Ghost integration, we'll still keep
        // the user subscribed locally, but log the error
        if (response && response.ghostError) {
          console.error('Ghost API error:', response.ghostError);
        }
      });
      
    } catch (error) {
      console.error('Error subscribing to newsletter:', error);
      alert('There was a problem subscribing you to the newsletter. Please try again.');
    }
  });
  
  // Check if already subscribed
  browserAPI.storage.local.get(['newsletter_subscribed'], function(result) {
    if (result.newsletter_subscribed) {
      form.style.display = 'none';
      successMessage.textContent = 'You are already subscribed to our newsletter!';
      successMessage.style.display = 'block';
    }
  });
});